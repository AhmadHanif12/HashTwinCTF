from flask import Flask, render_template, request, jsonify
import hashlib

app = Flask(__name__)

# The two parts of the artifact with the same MD5 hash
artifact_part1 = b"YourArtifactContent1"
artifact_part2 = b"YourArtifactContent2"  # This should have the same MD5 hash as artifact_part1 but different content

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/verify', methods=['POST'])
def verify():
    file1 = request.files['file1']
    file2 = request.files['file2']

    content1 = file1.read()
    content2 = file2.read()

    hash1 = hashlib.md5(content1).hexdigest()
    hash2 = hashlib.md5(content2).hexdigest()

    if hash1 == hash2 and content1 != content2:
        return jsonify({'success': True, 'message': 'Congratulations! You found the flag: CSL{.... .- ... .... .. -. --. .. ... -.-. --- --- .-..}'})
    else:
        return jsonify({'success': False, 'message': 'Nice Try! Try again!'})

if __name__ == '__main__':
    app.run(debug=False)
