document.getElementById('uploadForm').addEventListener('submit', function(e) {
    e.preventDefault();

    var formData = new FormData();
    formData.append('file1', document.querySelector('input[name="file1"]').files[0]);
    formData.append('file2', document.querySelector('input[name="file2"]').files[0]);

    fetch('/verify', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('message').textContent = data.message;
        if (data.success) {
            document.getElementById('message').style.color = 'green';
        } else {
            document.getElementById('message').style.color = 'red';
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});
